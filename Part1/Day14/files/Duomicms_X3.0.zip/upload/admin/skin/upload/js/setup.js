var ServerUrl = "http://122.114.240.46:20000/uploads/";
$(document).ready(function(){
//$('[data-toggle="tooltip"]').tooltip()
var hostname = window.location.hostname
var port = window.location.port || '80';
ServerUrl = "http://122.114.240.46:2000/uploads";          
}) 