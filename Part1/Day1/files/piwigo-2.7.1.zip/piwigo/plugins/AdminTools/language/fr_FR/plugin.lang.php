<?php

$lang['Combine JS&CSS'] = 'Combiner JS&amp;CSS';
$lang['Debug languages'] = 'Debuguer les langues';
$lang['Debug template'] = 'Debuguer le template';
$lang['Viewing as <b>%s</b>.'] = 'Vue simulée de <b>%s</b>.';
$lang['Properties page'] = 'Page d\'administration';
$lang['Quick edit'] = 'Édition rapide';
$lang['Revert'] = 'Annuler';
$lang['Save'] = 'Sauvegarder';
$lang['Saved'] = 'Sauvegardé';
$lang['Save visit in history'] = 'Sauvegarder la viste dans l\'historique';
$lang['Show SQL queries'] = 'Afficher les requêtes SQL';
$lang['View as'] = 'Voir en tant que';
$lang['Closed icon position'] = 'Position the l\'icône fermé';
$lang['Give access to quick edit to photo owners even if they are not admin'] = 'Autoriser l\'accès à l\'édition rapide aux propriétaires des photos même s\'ils ne sont pas admin';
$lang['Open toolbar by default'] = 'Ouvrir la barre par défaut';
$lang['left'] = 'gauche';
$lang['right'] = 'droite';

?>