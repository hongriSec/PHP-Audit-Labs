﻿<?php

/**
 * : pengwenfei p@simple-log.com
 * : 2011-02-04
 * www.simple-log.com 
*/ 


define('PBBLOG_WS_INCLUDES', 'includes');

define('PBBLOG_WS_ADMIN', 'admin');


/*数据库信息*/ 
$dbhost   = 'localhost';
//数据库主机地址
$dbname   = 'test';
//数据库名字
$dbuser   = 'root';
//用户名
$dbpw   = 'root';
//数据库密码
$dbprefix   = 'fb_';
//表前缀
$pconnect   = '';
//是否保持连接

/*会话、cookie设置*/ 
$cookie_path   = '/';
$cookie_domain   = '';
$session   = '1440';

/*网站编码，暂时只支持utf8*/ 
$charset   = 'utf8';

/*安全哈希密码*/ 
$hash_secret   = '14e7b128d3e9c7e';
//此处与全站的md5相关
$install_lock=false;  
//博客是否已经安装

?>