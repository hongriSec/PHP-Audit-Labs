<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:05
         compiled from footer.html */ ?>
</div>
<br class="clearfloat" />
<div id="footer">
<div class="u">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left">&copy;2009-2011 Powered by <a href="http://www.simple-log.com" target="_blank">Simple-Log</a> v1.6&nbsp;&nbsp;Theme Designed by <a href="http://HuHuaChuan.sinaapp.com" target="_blank">HuHuaChuan</a> <?php echo $this->_tpl_vars['icp_no']; ?>
</td>
      <td align="right"><?php echo $this->_tpl_vars['tj']; ?>
</td>
    </tr>
  </table>
  </div>
<div class="d"></div>
</div><!-- end #footer -->
</div><!-- end #container -->
</body>
</html>