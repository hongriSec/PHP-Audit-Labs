<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:05
         compiled from page.html */ ?>

<?php if ($this->_tpl_vars['page_count'] > 1): ?>
<div id="page">
<ol class="pages">
总共<?php echo $this->_tpl_vars['page_count']; ?>
页，当前第<?php echo $this->_tpl_vars['pg']; ?>
页 | 页数：
<?php $_from = $this->_tpl_vars['page_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['page']):
?>
<li <?php if ($this->_tpl_vars['pg'] == $this->_tpl_vars['page']['value']): ?>class="current"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['page']['url']; ?>
" ><?php echo $this->_tpl_vars['page']['name']; ?>
</a></li>
<?php endforeach; endif; unset($_from); ?>
</ol>
</div>
<?php endif; ?>