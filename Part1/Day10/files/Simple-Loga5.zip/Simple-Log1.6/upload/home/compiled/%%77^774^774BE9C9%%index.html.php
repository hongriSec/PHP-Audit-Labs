<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:05
         compiled from index.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div id="content">
<?php if ($this->_tpl_vars['blog_notice']): ?>
<div id="blog_notice"><?php echo $this->_tpl_vars['blog_notice']; ?>
</div>
<?php endif; ?>
<?php $_from = $this->_tpl_vars['blog_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['blog']):
?>
<div class="post">
	<div class="info">
    <div class="info_l"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="22">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
#pl"><?php echo $this->_tpl_vars['blog']['comments']; ?>
</a></td>
  </tr>
</table>
</div>
    <div class="info_r"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="24" valign="top"><h3 class="title"><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
" ><?php if ($this->_tpl_vars['blog']['is_top'] == 1): ?>[置顶]<?php endif; ?><?php echo $this->_tpl_vars['blog']['title']; ?>
</a></h3> </td>
  </tr>
  <tr>
    <td height="20" valign="bottom"><span>发表者：<?php echo $this->_tpl_vars['blog']['user_name']; ?>
</span><span><a href="<?php echo $this->_tpl_vars['blog']['cat_url']; ?>
">分类：<?php echo $this->_tpl_vars['blog']['cat_name']; ?>
</a></span><span><?php echo $this->_tpl_vars['blog']['add_time']; ?>
</span>  
	  <span><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
" >阅读[<?php echo $this->_tpl_vars['blog']['views']; ?>
]</a></span></td>
  </tr>
</table>
</div>
</div>
<div class="center">
<?php echo $this->_tpl_vars['blog']['description']; ?>

</div>
<div class="tag"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="30" valign="middle">Tags：<?php echo $this->_tpl_vars['blog']['tags']; ?>
</td>
    <td align="right" valign="middle"><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
">[阅读全文...]</a></td>
  </tr>
</table>
</div>
  </div>
<?php endforeach; endif; unset($_from); ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "page.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>