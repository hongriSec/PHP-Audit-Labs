<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:05
         compiled from header.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo $this->_tpl_vars['page_title']; ?>
</title>
<meta name="description" content="<?php echo $this->_tpl_vars['desc']; ?>
">
<meta name="generator" content="Simple-Log 1.3.1" />
<meta name="author" content="Simple-Log Team" />
<meta name="copyright" content="Simple-Log" />
<link href="<?php echo $this->_tpl_vars['domain']; ?>
<?php echo $this->_tpl_vars['templates_dir']; ?>
style.css" media="all" rev="stylesheet" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php echo $this->_tpl_vars['domain']; ?>
index.php?app=feed" />
<script src="<?php echo $this->_tpl_vars['domain']; ?>
includes/js/jquery.js"></script>
</head>
<body>


  <div id="header">
  <div class="logo">
  <div class="l_l"><a href="<?php echo $this->_tpl_vars['domain']; ?>
index.php"><img src="<?php echo $this->_tpl_vars['domain']; ?>
<?php echo $this->_tpl_vars['templates_dir']; ?>
images/logo.png" border="0" /></a></div>
  <div class="l_r"> <a href="<?php echo $this->_tpl_vars['domain']; ?>
index.php"><?php echo $this->_tpl_vars['blog_name']; ?>
</a></div>
  </div>
    <div id="nav">
  <div class="dh_l">
  	<ul>
	<?php $_from = $this->_tpl_vars['nav_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['nav']):
?>
    <li <?php if ($this->_tpl_vars['nav']['current'] == 1): ?>class="current"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['nav']['content']; ?>
" title="<?php echo $this->_tpl_vars['nav']['desc']; ?>
"><?php echo $this->_tpl_vars['nav']['title']; ?>
</a></li>
	<?php endforeach; endif; unset($_from); ?>
	</ul>
  </div>
  <div class="dh_r"><a href="<?php echo $this->_tpl_vars['domain']; ?>
index.php?app=feed" target="_blank"><img src="<?php echo $this->_tpl_vars['domain']; ?>
<?php echo $this->_tpl_vars['templates_dir']; ?>
images/Rss.png" alt="Rss" border="0" /></a></div>
</div>
  </div>  <!-- end #header -->
  
  <div id="container">

  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "sidebar.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?> 