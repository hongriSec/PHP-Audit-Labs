<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:06
         compiled from blog.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('insert', 'comments_name', 'blog.html', 52, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div id="content">
<div class="post">
	<div class="info">
    <div class="info_l"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="22">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
#pl"><?php echo $this->_tpl_vars['blog']['comments']; ?>
</a></td>
  </tr>
</table>
</div>
    <div class="info_r"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="24" valign="top"><h3 class="title"><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
" ><?php if ($this->_tpl_vars['blog']['is_top'] == 1): ?>[置顶]<?php endif; ?><?php echo $this->_tpl_vars['blog']['title']; ?>
</a></h3> </td>
  </tr>
  <tr>
    <td height="20" valign="bottom"><span>发表者：<?php echo $this->_tpl_vars['blog']['user_name']; ?>
</span><span><a href="<?php echo $this->_tpl_vars['blog']['cat_url']; ?>
">分类：<?php echo $this->_tpl_vars['blog']['cat_name']; ?>
</a></span><span><?php echo $this->_tpl_vars['blog']['add_time']; ?>
</span>  
	  <span><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
" >阅读[<?php echo $this->_tpl_vars['blog']['views']; ?>
]</a></span></td>
  </tr>
</table>
</div>
</div>
<div class="blog_center">
<?php echo $this->_tpl_vars['blog']['content']; ?>

</div>
<div class="tag"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="30" valign="middle">Tags：<?php echo $this->_tpl_vars['blog']['tags']; ?>
</td>
    <td align="right" valign="middle"><a href="<?php echo $this->_tpl_vars['blog']['url']; ?>
">[阅读全文...]</a></td>
  </tr>
</table>
</div>
</div>

<!--<?php if ($this->_tpl_vars['open_comment'] == 1): ?>-->
<div class="new_notice">网站已经关闭评论</div>
<!--<?php elseif ($this->_tpl_vars['blog']['open_type'] == 1): ?>-->
<div class="new_notice">此日志评论已经关闭</div>
<!--<?php else: ?>-->
<div class="pl"> 
<div id="replay">
<div id="replay_box">
<a name="pl"></a>
    <form action="post.php?act=pl_post" method="post"  name="post_comment" id="post_comment" >
<div id="post_comments_notice" style="display:none;padding-bottom:5px;clear:both;font-size: 13px;font-family: verdana,arial; color:#FF0000">评论数据提交中......</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="500" rowspan="2"><textarea class="textarea_all" name="content" cols="40" rows="5"></textarea></td>
    <td><?php require_once(SMARTY_CORE_DIR . 'core.run_insert_handler.php');
echo smarty_core_run_insert_handler(array('args' => array('name' => 'comments_name')), $this); ?>
 </td>
  </tr>
  <tr>
    <td><input class="button_all" type="button" name="button" id="comment_button1" onclick="post()"  />
    </td>
  </tr>
</table>
</form>
</div>
</div>
<p class="p_list"><a onclick="post()">评论列表</a></p>
<div id="load_comments_notice" style="display:none;font-size: 13px;font-family: verdana,arial; color:#FF0000">评论数据加载中......</div>
<ol id="comments_list"></ol></div>
<!--<?php endif; ?>-->

<script type="text/javascript">
var id=<?php echo $this->_tpl_vars['blog']['blog_id']; ?>
;
var u='<?php echo $this->_tpl_vars['domain']; ?>
';
<!-- <?php echo ' -->
$(\'#load_comments_notice\').css("display","block");
var geturl=u+"/post.php?act=comments_list&id="+id;
$.getJSON(geturl,
function(data){
	$(\'#comments_list\').html(data.content);
	$(\'#load_comments_notice\').css("display","none");
});


function post()
{
	comment_id=$(\'#post_comments_id\').html();
	$(\'#post_comments_notice\').show();
	var params=$(\'input\').serialize();
	p=params+\'&content=\'+$(\'textarea\').val();
	var ajaxurl=u+\'/post.php?act=post_comment&id=\'+id+\'&comment_id=\'+comment_id;
	$.ajax({url:ajaxurl,type:\'post\', dataType:\'json\',data:p,success:update_comments});
}

function update_comments(data)
{
	$(\'#post_comments_notice\').css("display","block");
	if(data.error!=\'no\')
	{
		$(\'#post_comments_notice\').html(data.error);
	}
	else
	{
		$(\'#post_comments_notice\').html(\'评论发布成功\');
		var post_form=$(\'#replay_box\').html();
		$(\'#replay\').html(\'<div id="replay_box">\'+post_form+\'</div>\');
		$(\'#comments_list\').html(data.content);
		$(\'textarea\').val(\'\');
		$(\'#post_comments_id\').remove(); //请客回复id
	}
}

function replay(comment_id)
{
	$(\'#post_comments_notice\').html(\'\');
	$(\'#post_comments_id\').remove(); //请客回复id
	var post_form=$(\'#replay_box\').html();
	$("#replay_box").remove();
	$(\'#box-\'+comment_id).append(\'<div id="replay_box">\'+post_form+\'<div id="post_comments_id" style="display:none;">\'+comment_id+\'</div></div><p>&nbsp;</p>\');
}

function page(page_id)
{
	$(\'#load_comments_notice\').css("display","block");
	var geturl=u+"/post.php?act=comments_list&id="+id+"&pg="+page_id;
	$.getJSON(geturl,
	function(data){
		$(\'#comments_list\').html(data.content);
		$(\'#load_comments_notice\').css("display","none");
	}); 
}

	<!-- '; ?>
 -->
</script>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "page.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>