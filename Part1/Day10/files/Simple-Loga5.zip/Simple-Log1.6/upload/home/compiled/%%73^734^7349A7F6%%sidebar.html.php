<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:05
         compiled from sidebar.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('insert', 'member_info', 'sidebar.html', 4, false),)), $this); ?>
<div id="sidebar"> 
<div class="system sidebar_all">
<div class="c_1 c1_all"><h2>系统导航</h2></div> 
<div class="c_2 c2_all"><?php require_once(SMARTY_CORE_DIR . 'core.run_insert_handler.php');
echo smarty_core_run_insert_handler(array('args' => array('name' => 'member_info')), $this); ?>
</div>
<div class="c_3 c3_all"></div>
</div><!--//system-->

<div class="class sidebar_all">
<div class="c_1 c1_all"><h2>日志分类</h2></div>
<div class="c_2 c2_all">
        <ul>
		<?php $_from = $this->_tpl_vars['cat']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['cat_val']):
?>
			<li><a href=<?php echo $this->_tpl_vars['cat_val']['url']; ?>
 title=<?php echo $this->_tpl_vars['cat_val']['cat_desc']; ?>
><?php echo $this->_tpl_vars['cat_val']['cat_name']; ?>
</a></li>
			<?php if ($this->_tpl_vars['cat_val']['children']): ?>
     		  	<?php $_from = $this->_tpl_vars['cat_val']['children']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['children']):
?>
     		  	<li class="children"><a href=<?php echo $this->_tpl_vars['children']['url']; ?>
 title=<?php echo $this->_tpl_vars['children']['cat_desc']; ?>
><?php echo $this->_tpl_vars['children']['cat_name']; ?>
</a></li>
      		    <?php endforeach; endif; unset($_from); ?>
  			<?php endif; ?>
		<?php endforeach; endif; unset($_from); ?>
		</ul>
        </div>
<div class="c_3 c3_all"></div>
</div><!--//class-->

<div class="search sidebar_all">
<div class="c_1 c1_all"><h2>搜索</h2></div> 
<div class="c_2 c2_all">
          <form  method="get" action="<?php echo $this->_tpl_vars['domain']; ?>
search.php">
			<div class="s_k">
			  <input class="s" type="text" name="s"  size="10" />
			  <input class="submit" name="submit" type="submit" tabindex="5" value="搜索" />
            </div>
	  </form>
</div>
<div class="c_3 c3_all"></div>
</div> <!--//search-->

<div class="file sidebar_all">   
<div class="c_1 c1_all"><h2>日志归档</h2></div> 
<div class="c_2 c2_all">
		<ul>
		<?php $_from = $this->_tpl_vars['archives']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['archives_val']):
?>
			<li><a href=<?php echo $this->_tpl_vars['archives_val']['url']; ?>
><?php echo $this->_tpl_vars['archives_val']['data']; ?>
</a></li>
		<?php endforeach; endif; unset($_from); ?>
		</ul>
</div>
<div class="c_3 c3_all"></div>
</div><!--//file-->

<div class="sub sidebar_all">
<div class="c_1 c1_all"><h2>网站订阅</h2></div>
<div class="c_2 c2_all">
		<ul>
         <li><a href="http://fusion.google.com/add?feedurl=<?php echo $this->_tpl_vars['feed_url']; ?>
" target="_blank"><img border="0" src="<?php echo $this->_tpl_vars['domain']; ?>
images/icon_subshot02_google.gif" alt="google reader" vspace="2" style="margin-right:8px;" ></a></li>
    	<li><a href="http://www.zhuaxia.com/add_channel.php?url=<?php echo $this->_tpl_vars['feed_url']; ?>
" target="_blank"><img border="0" src="<?php echo $this->_tpl_vars['domain']; ?>
images/icon_subshot02_zhuaxia.gif" alt="&#25235;&#34430;" vspace="2" ></a></li>
    	<li><a href="http://reader.yodao.com/#url=<?php echo $this->_tpl_vars['feed_url']; ?>
" target="_blank"><img border="0" src="<?php echo $this->_tpl_vars['domain']; ?>
images/icon_subshot02_youdao.gif" alt="&#26377;&#36947;" vspace="2" ></a></li>
    	<li><a href="http://www.pageflakes.com/subscribe.aspx?url=<?php echo $this->_tpl_vars['feed_url']; ?>
" target="_blank"><img border="0" src="<?php echo $this->_tpl_vars['domain']; ?>
images/icon_subshot02_pageflakes.gif" alt="pageflakes" vspace="2" style="margin-right:8px;" ></a></li>
    	<li><a href="http://add.my.yahoo.com/rss?url=<?php echo $this->_tpl_vars['feed_url']; ?>
" target="_blank"><img border="0" src="<?php echo $this->_tpl_vars['domain']; ?>
images/icon_subshot02_yahoo.gif" alt="my yahoo" vspace="2" ></a></li>
		</ul>
</div>
<div class="c_3 c3_all"></div>
</div><!--//sub-->

<div class="link sidebar_all">
<div class="c_1 c1_all"><h2>友情链接</h2></div> 
<div class="c_2 c2_all">
        <ul>
		<?php $_from = $this->_tpl_vars['link_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['link']):
?>
			<li><a href=<?php echo $this->_tpl_vars['link']['url']; ?>
 title=<?php echo $this->_tpl_vars['link']['desc']; ?>
><?php echo $this->_tpl_vars['link']['title']; ?>
</a></li>
		<?php endforeach; endif; unset($_from); ?>
		</ul>
</div>
<div class="c_3 c3_all"></div>
</div><!--//link-->
        
<div class="new sidebar_all">       
<div class="c_1 c1_all"><h2>最新文章</h2></div>
<div class="c_2 c2_all">
        <ul>
		<?php $_from = $this->_tpl_vars['new_article']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['new_article_val']):
?>
			<li><a href=<?php echo $this->_tpl_vars['new_article_val']['url']; ?>
 title=<?php echo $this->_tpl_vars['new_article_val']['title']; ?>
><?php echo $this->_tpl_vars['new_article_val']['title']; ?>
</a></li>
		<?php endforeach; endif; unset($_from); ?>
		</ul>
</div>
<div class="c_3 c3_all"></div>
</div>

<!--//new-->
</div><!--//sidebar-->