<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:06
         compiled from header.html */ ?>
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->_tpl_vars['admin_title']; ?>
</title>
<link href="templates/style.css" media="all" rev="stylesheet" rel="stylesheet" type="text/css" />
<script src="../includes/js/jquery.js" type="text/javascript"></script>
</head>
<body class="body">
<div id="main">
  <div id="content">
  <div class="admin_here">
  <?php echo $this->_tpl_vars['admin_here']; ?>

   </div><br />