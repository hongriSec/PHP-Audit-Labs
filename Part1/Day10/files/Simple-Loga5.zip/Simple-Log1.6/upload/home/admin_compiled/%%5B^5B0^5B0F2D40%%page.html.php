<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:06
         compiled from page.html */ ?>
<div class="page">
总共<?php echo $this->_tpl_vars['page_count']; ?>
页，当前第<?php echo $this->_tpl_vars['pg']; ?>
页 | 页数：
<?php $_from = $this->_tpl_vars['page_arr']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['page']):
?>
<a href="<?php echo $this->_tpl_vars['url']; ?>
<?php echo $this->_tpl_vars['page']['value']; ?>
" <?php if ($this->_tpl_vars['pg'] == $this->_tpl_vars['page']['value']): ?>class="page_current"<?php endif; ?> ><?php echo $this->_tpl_vars['page']['name']; ?>
</a>
<?php endforeach; endif; unset($_from); ?>
</div>