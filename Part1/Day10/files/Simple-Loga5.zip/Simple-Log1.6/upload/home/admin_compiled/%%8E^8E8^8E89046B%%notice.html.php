<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:04
         compiled from notice.html */ ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>跳转提示</title>
<meta http-equiv="refresh" content="2;URL=<?php echo $this->_tpl_vars['new_url']; ?>
">
<link href="templates/style.css" media="all" rev="stylesheet" rel="stylesheet" type="text/css" />
</head>
<body class="body">
<div id="main">
  <div id="content">
  <center>
<div style="border: 1px solid #739ACE;background: #f2fcfb; margin-top:150px; margin-left:auto; margin-right:auto; width:400px; ">
<br />
<p align="center">系统跳转提示</p>
<p align="center"><?php echo $this->_tpl_vars['msg']; ?>
，正在跳转...</p>
<p align="center"><a href="<?php echo $this->_tpl_vars['referer_url']; ?>
">返回上一页</a> <a href="<?php echo $this->_tpl_vars['domain']; ?>
">首页</a> <a href="<?php echo $this->_tpl_vars['new_url']; ?>
">跳转</a></p>
<br />
</div>
</center>
</div></div>
</body>
</html>