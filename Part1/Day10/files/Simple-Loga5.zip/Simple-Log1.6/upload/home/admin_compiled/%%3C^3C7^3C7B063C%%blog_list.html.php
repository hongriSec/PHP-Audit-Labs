<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:06
         compiled from blog_list.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php echo '
<script type="text/javascript"> 
function checkAll(frm, checkbox)
{
	for (i = 0; i < frm.elements.length; i++)
	{
		if (frm.elements[i].name == \'blog_arr[]\')
		{
			frm.elements[i].checked = checkbox.checked;
		}
	}
}

function check(list, obj)
{
	var frm = obj.form;

	for (i = 0; i < frm.elements.length; i++)
	{
		if (frm.elements[i].name == "action_code[]")
		{
			var regx = new RegExp(frm.elements[i].value + "(?!_)", "i");

			if (list.search(regx) > -1) frm.elements[i].checked = obj.checked;
		}
	}
}
</script>
'; ?>

<div class="admin_here">
<form action="admin.php?act=blog_list" method="post" name="group_form">
  <input type="text" name="keywords"  value="" />    <input type="submit" name="button" id="button" value="搜索" /></td>
</form>
</div>
<p><form action="admin.php?act=del_blog" method="post" name="group_form">
<table width="100%" >
  <tr class="tr1">
    <td>博客标题</td>
    <td>添加时间</td>
    <td>所属分类</td>
    <td>作者</td>
    <td>操作</td>
  </tr>
  <?php $_from = $this->_tpl_vars['blog_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['blog']):
?>
  <tr>
    <td><input type="checkbox" name="blog_arr[]" value="<?php echo $this->_tpl_vars['blog']['blog_id']; ?>
"  class="checkbox" /><a href="admin.php?act=edit_blog&id=<?php echo $this->_tpl_vars['blog']['blog_id']; ?>
"><?php echo $this->_tpl_vars['blog']['title']; ?>
</a></td>
    <td><?php echo $this->_tpl_vars['blog']['add_time']; ?>
</a></td>
    <td><?php echo $this->_tpl_vars['blog']['cat_name']; ?>
</td>
    <td><?php echo $this->_tpl_vars['blog']['user_name']; ?>
</td>
    <td><a href="admin.php?act=edit_blog&id=<?php echo $this->_tpl_vars['blog']['blog_id']; ?>
" >编辑</a> | <a href="admin.php?act=del_blog&id=<?php echo $this->_tpl_vars['blog']['blog_id']; ?>
" >删除</a> </td>
  </tr>
  <?php endforeach; endif; unset($_from); ?>
    <tr>
    <td><input type="checkbox" name="checkall" value="checkbox" onclick="checkAll(this.form, this);" class="checkbox" />全选   
      <input type="submit" name="button" id="button" value="删除" /></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table></form>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "page.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</p>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>