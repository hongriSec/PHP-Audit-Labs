<?php /* Smarty version 2.6.22, created on 2013-01-04 23:33:06
         compiled from footer.html */ ?>
<br class="clearfloat" />
   <div id="footer">
   <p>&copy;2009-2011 Powered by <a href="http://www.simple-log.com">Simple-Log</a></p>
  <!-- end #footer --></div></div>
</body>
</html>