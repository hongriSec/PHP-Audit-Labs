<?php

$type=1;				//1表示边栏模块
$id='sysnav';			//id为该模块唯一标识

$modules['sysnav']['title']='系统导航';
$modules['sysnav']['desc']='系统导航';
$modules['sysnav']['content']="{insert name='member_info'}";
?>