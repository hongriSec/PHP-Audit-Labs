<?php

/**
 * $Author: pengwenfei p@simple-log.com
 * $Date: 2012-12-02
 * www.simple-log.com 
*/

define('IN_PBBLOG', true);
require(dirname(__FILE__) . '/includes/core.php');
$app=$arg='';

//映射地址
$routemap=intval($_GET['routemap']);
if ($routemap==2) 
{
	start_route();
}
else 
{
	start_index();
}


require(dirname(__FILE__) . '/includes/modules/sys/'.$app.'.php');



?>