<?php

return array(

	'menu' => 'Menu',

);