<?php

return array(
	'report' => true,
	'logger' => function($exception) {}
);