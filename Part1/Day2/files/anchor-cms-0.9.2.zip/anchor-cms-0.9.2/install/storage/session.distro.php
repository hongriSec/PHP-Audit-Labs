<?php

return array(
	'driver' => 'database',
	'cookie' => 'anchorcms',
	'table' => '{{table}}',
	'lifetime' => 86400,
	'expire_on_close' => false,
	'path' => '/',
	'domain' => '',
	'secure' => false
);