		<small>
			You’re installing Anchor version <?php echo VERSION; ?>.
			<a href="//twitter.com/anchorcms" target="_blank">Need help?</a>
		</small>
	</body>
</html>